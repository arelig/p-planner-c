var searchData=
[
  ['reducirhorasmanejo',['reducirHorasManejo',['../planificador_8c.html#a9f7836e733d3d640332c9effb73e18e2',1,'planificador.c']]]
];
