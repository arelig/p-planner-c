var searchData=
[
  ['ultimo_5fhijo',['ultimo_hijo',['../colacp_8c.html#aff136e024ca2eb3883c223720f9acdeb',1,'colacp.c']]],
  ['upheap',['upHeap',['../colacp_8c.html#a19086a796738ef3442ad93fa7f7c0853',1,'colacp.c']]]
];
