var searchData=
[
  ['eliminar_5fultimo_5fhijo',['eliminar_ultimo_hijo',['../colacp_8c.html#af9917bbf07a48a8528f5044041344d4c',1,'colacp.c']]]
];
