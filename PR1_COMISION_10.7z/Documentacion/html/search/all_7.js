var searchData=
[
  ['hijo_5fderecho',['hijo_derecho',['../structnodo.html#a6e36a9d6f937b6b237b061c5aae9b2e8',1,'nodo']]],
  ['hijo_5fizquierdo',['hijo_izquierdo',['../structnodo.html#ab5297f7700d17e51c01045ba71b5a29d',1,'nodo']]],
  ['hijo_5fmenor',['hijo_menor',['../colacp_8c.html#a5626d4c606c1dc343834504d40498365',1,'colacp.c']]]
];
