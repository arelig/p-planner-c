var searchData=
[
  ['ele_5fnulo',['ELE_NULO',['../define_8h.html#a3f5c15260e66d63c82a73554413fb25c',1,'define.h']]],
  ['elemento',['elemento',['../structcelda.html#ab56b380a5c2fc289dce23583f253d7b2',1,'celda']]],
  ['eliminar_5fultimo_5fhijo',['eliminar_ultimo_hijo',['../colacp_8c.html#af9917bbf07a48a8528f5044041344d4c',1,'colacp.c']]],
  ['entrada',['entrada',['../structentrada.html',1,'entrada'],['../structnodo.html#a1952106a1bacf893781409ff192405ce',1,'nodo::entrada()']]]
];
