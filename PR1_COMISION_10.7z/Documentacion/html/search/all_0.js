var searchData=
[
  ['archivo_5fcorrupto',['ARCHIVO_CORRUPTO',['../define_8h.html#a01fb74e084ec2ee506115b3784dd4b94',1,'define.h']]]
];
