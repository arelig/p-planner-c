var searchData=
[
  ['cantidad_5felementos',['cantidad_elementos',['../structcola__con__prioridad.html#aa53366df68271654d61b63ac31790fea',1,'cola_con_prioridad']]],
  ['celda_5fanterior',['celda_anterior',['../structcelda.html#a3ec0da00d6e316f5de18ed7e01e68cb1',1,'celda']]],
  ['celda_5fsiguiente',['celda_siguiente',['../structcelda.html#aee99de557c5cd3bedfdf0f5f5624831c',1,'celda']]],
  ['clave',['clave',['../structentrada.html#a8a5d65730d1f86191123a73ed80025ac',1,'entrada']]],
  ['comparador',['comparador',['../colacp_8c.html#a0dca0299eae4736eacb961f04f6c44b1',1,'colacp.c']]]
];
