var searchData=
[
  ['valor',['valor',['../structentrada.html#ae4d5d003c617d6e0c09ae11231430463',1,'entrada']]]
];
