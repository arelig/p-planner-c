var searchData=
[
  ['cp_5fdestruir',['cp_destruir',['../colacp_8c.html#ac03f4013b3ca1f53d68c0655429870be',1,'cp_destruir(TColaCP cola):&#160;colacp.c'],['../colacp_8h.html#ac03f4013b3ca1f53d68c0655429870be',1,'cp_destruir(TColaCP cola):&#160;colacp.c']]],
  ['cp_5feliminar',['cp_eliminar',['../colacp_8c.html#a30afcf158180539bca9039c890c53e4f',1,'cp_eliminar(TColaCP cola):&#160;colacp.c'],['../colacp_8h.html#a30afcf158180539bca9039c890c53e4f',1,'cp_eliminar(TColaCP cola):&#160;colacp.c']]],
  ['cp_5finsertar',['cp_insertar',['../colacp_8c.html#a9b75a469a7ebad09e25373c679696d37',1,'cp_insertar(TColaCP cola, TEntrada entr):&#160;colacp.c'],['../colacp_8h.html#a9b75a469a7ebad09e25373c679696d37',1,'cp_insertar(TColaCP cola, TEntrada entr):&#160;colacp.c']]],
  ['cp_5fsize',['cp_size',['../colacp_8c.html#a86fe02bd1d0d2d116eabedc2ecfbe507',1,'cp_size(TColaCP cola):&#160;colacp.c'],['../colacp_8h.html#a86fe02bd1d0d2d116eabedc2ecfbe507',1,'cp_size(TColaCP cola):&#160;colacp.c']]],
  ['crear_5fcola_5fcp',['crear_cola_cp',['../colacp_8c.html#a47f0005b423089b2132a76dda40fac24',1,'crear_cola_cp(TColaCP *cola, int(*f)(TEntrada p, TEntrada q)):&#160;colacp.c'],['../colacp_8h.html#a47f0005b423089b2132a76dda40fac24',1,'crear_cola_cp(TColaCP *cola, int(*f)(TEntrada p, TEntrada q)):&#160;colacp.c']]],
  ['crear_5flista',['crear_lista',['../lista_8c.html#a14595ca8acb015f5d0a1f1da90813a52',1,'crear_lista(TLista *lista):&#160;lista.c'],['../lista_8h.html#a14595ca8acb015f5d0a1f1da90813a52',1,'crear_lista(TLista *lista):&#160;lista.c']]]
];
