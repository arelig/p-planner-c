var searchData=
[
  ['pos_5fnula',['POS_NULA',['../define_8h.html#a49e7e2daa209c00cb9fc2a442ae30a6c',1,'define.h']]]
];
