var searchData=
[
  ['lista_2ec',['lista.c',['../lista_8c.html',1,'']]],
  ['lista_2eh',['lista.h',['../lista_8h.html',1,'']]]
];
