var searchData=
[
  ['ordenarinformacion',['ordenarInformacion',['../planificador_8c.html#a93b652a9ff826dd67b10760eab893966',1,'planificador.c']]]
];
