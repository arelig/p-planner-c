var searchData=
[
  ['padre',['padre',['../structnodo.html#abd4503f5f5d60e2ee1a53e4774b432c4',1,'nodo']]],
  ['pos_5fx',['pos_x',['../structciudad.html#a989d3e09b707fb1f4bc2355ba5855a0c',1,'ciudad']]],
  ['pos_5fy',['pos_y',['../structciudad.html#a769c689813b19fb03572dc4937b40993',1,'ciudad']]]
];
