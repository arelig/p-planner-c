var searchData=
[
  ['nombre',['nombre',['../structciudad.html#a2a4ee52b46cf8d757bd19a4871dafb73',1,'ciudad']]]
];
