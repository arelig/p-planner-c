#include <stdio.h>
#include <stdlib.h>

typedef struct ciudad
{
    char* nombre;
    int pos_x;
    int pos_y;
} *TCiudad;